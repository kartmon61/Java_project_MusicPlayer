package music;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import javax.swing.JOptionPane;
import javazoom.jl.player.Player;

public class MusicPlayer 
{
	Player player; // player
	
	private FileInputStream input;
	private BufferedInputStream buffer;
	private boolean resumeFlag; // flag for whether resume or not
	private String path; // path
	
	public int total; // total number of frames
	public int stopped; // stopped position of frames
	private boolean valid; // valid or not

	public MusicPlayer() 
	{
		player = null; input = null; valid = false;
		buffer = null; path = null; resumeFlag = false;
		total = 0; stopped = 0;
	}

	public boolean resumeFlag() { return resumeFlag; }
	public void setPath(String path) { this.path = path; }
	
	public boolean play(int pos) 
	{
		valid = true;
		resumeFlag = false;
		try 
		{
			input = new FileInputStream(path);
			total = input.available();
			
			if (pos > -1)
				input.skip(pos);
			
			buffer = new BufferedInputStream(input);
			player = new Player(buffer);
			new Thread(new Runnable() 
			{
				public void run() 
				{
					try 
					{
						player.play();
					} 
					catch (Exception e) 
					{
						JOptionPane.showMessageDialog(null, "Error playing mp3 file");
						valid = false;
					}
				}
			}).start();
		} 
		catch (Exception e) 
		{
			JOptionPane.showMessageDialog(null, "Error playing mp3 file");
			valid = false;
		}
		return valid;
	}

	public void pause() 
	{
		try 
		{
			stopped = input.available();
			player.close(); // close player
			
			input = null; buffer = null; player = null;
			
			if (valid)
				resumeFlag = true;
		} 
		catch (Exception e) { e.printStackTrace(); }
	}

	public void resume() 
	{
		if (!resumeFlag)
			return;
		if (play(total - stopped)) // resume at stopped position
			resumeFlag = false;
	}
}