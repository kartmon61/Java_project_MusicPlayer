package music;

import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.SwingWorker;

public class ProgressBar extends SwingWorker<Void, Integer> 
{
	private JProgressBar progressBar;
	private JLabel lblTime;
	public String totalTimeString;
	public int totalSec;
	private int min;
	private int sec;
	public String currentPlayingTime;
	public static int currentTotalSec = 0;
	public boolean pause_set = false;

	/* Constructor */
	public ProgressBar(JProgressBar progressBar, JLabel lblTime, Music m) 
	{
		super();
		this.progressBar = progressBar;
		this.lblTime = lblTime;
		this.totalTimeString = m.getMusicTime();
		// get the time and parsing
		String[] split = totalTimeString.split(":");

		this.min = Integer.parseInt(split[0]);
		this.sec = Integer.parseInt(split[1]);
		this.totalSec = min * 60 + sec;
	}

	@Override
	protected Void doInBackground() throws Exception 
	{
		int minute = 0;
		int second = 0;
		// set formatting minute
		String minuteString = String.format("%02d", minute);
		// set formatting second
		String secondString = String.format("%02d", second);
		
		try 
		{
			for (int i = 0; i < totalSec; i++) 
			{
				Thread.sleep(1000);

				progressBar.setValue(i * 100 / totalSec); // show the progressBar 0-100
				second += 1;
				// update minute
				if (i % 60 == 0 && i != 0) 
				{
					minute += 1;
					minuteString = String.format("%02d", minute);
					second -= 60;
				}
				// update secondString
				secondString = String.format("%02d", second);
				// show Time
	            String totalMin = String.format("%02d", min);
	            String totalSec = String.format("%02d", sec);
	            
	            lblTime.setText(minuteString + ":" + secondString + " / " + totalMin + ":" + totalSec);
			}
		} 
		catch (InterruptedException e) { System.out.println("Music Stopped"); }

		return null;
	}
}