/** 
 * 12131819 YOOK DONGHYUN, 12345678 LEE JINHO
 * Java Application Programming-002 (Prof. Tamer) // Final Project
 * ============================================================================
 * update log
 * -----------------------------------------------------------------------------
 * - 2019.06.09 : code-refactoring and put some comments on each code (by YOOK)
 */
package music;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.JScrollPane;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.Font;
import java.awt.Insets;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import javax.swing.JProgressBar;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JSlider;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class MainGUI extends JFrame implements ActionListener, KeyListener
{
   private static final long serialVersionUID = 1L;
   
   /** GUI Components */
   private JFrame frame;
   private JPanel pnlSongName;
   private JLabel lblSongTitle;
   private JLabel lblArtistTitle;
   private JPanel pnlOutput;
   private JPanel pnlTimeOutput;
   private JPanel pnlMenu;
   private JLabel lblOpenFile;
   private JLabel lblOpenPlaylist;
   private JLabel lblAddSong;
   private JLabel lblNewPlaylist;
   private JLabel lblRemoveSong;
   private JLabel lblSavePlaylist;
   private JLabel lblRemovePlaylist;
   private JButton btnOpenFile;
   private JButton btnAddSong;
   private JButton btnRemoveSong;
   private JButton btnOpenPlaylist;
   private JButton btnNewPlaylist;
   private JButton btnSavePlaylist;
   private JButton btnRemovePlaylist;
   private JPanel pnlList;
   private JPanel pnlShowList;
   private JLabel lblSongName;
   private JLabel lblArtist;
   private JLabel lblDuration;
   private JScrollPane scrollPane;
   private JPanel pnlTime;
   private JPanel pnlController;
   private JLabel lblTime;
   private JProgressBar progressBar;
   private JButton btnBack;
   private JButton btnPlay;
   private JButton btnPause;
   private JButton btnStop;
   private JButton btnNext;
   private JLabel lblVol;
   private JSlider slider;
   private JPanel pnlButton;
   private JPanel pnlVolume;
   private JLabel lblVolSize;
   
   private JList list;
   private DefaultListModel listModel;

   /** User-defined Member Fields */
   private ArrayList<String> musicList; // list for string
   private ArrayList<Music> music; // list for Music object
   
   private int musicNum; // number of music
   private String musicName; // name of music
   private String musicArtist; // artist of music
   private String musicTime; // duration of music 
   private String musicPath; // path of music 
   private String fileName; // file name of music 
   private String filePath; // file path of music
   
   private MusicPlayer player = new MusicPlayer(); // thread for MP3 playing
   private VolumeController volumeController = new VolumeController(0.5F); // thread for volume controlling
   private ProgressBar progB; // thread for progress bar controlling
   
   private boolean pause_flag = false; // control pause mechanism
   private boolean play_flag = false; // control play mechanism
   

   /** Launch the application */
   public static void main(String[] args) 
   {
      EventQueue.invokeLater(new Runnable() 
      {
         public void run() 
         {
            try 
            {
               MainGUI window = new MainGUI();
               window.frame.setVisible(true);
            } 
            catch (Exception e) { e.printStackTrace(); }
         }
      });
   }

   /** Create the application */
   public MainGUI() { initialize(); }

   /** Initialize the contents of the frame */
   private void initialize() 
   {
      /* JFrame */
      try 
      {
    	  // Apply Look and Feel
    	  UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
    	  JFrame.setDefaultLookAndFeelDecorated(true);
	  } 
      catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e1) { e1.printStackTrace(); } 
      
      frame = new JFrame("Music Player");
      frame.setBounds(100, 100, 565, 642);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      
      /** ====================== Header of music player ========================== */
      /* Panel for song name */
      pnlSongName = new JPanel();
      pnlSongName.setBorder(new EmptyBorder(20, 10, 10, 10));
      frame.getContentPane().add(pnlSongName, BorderLayout.NORTH);
      pnlSongName.setLayout(new GridLayout(0, 1, 0, 0));
      
      /* Label for song title */
      lblSongTitle = new JLabel("Sample Song Name");
      lblSongTitle.setFont(new Font("Nanum Gothic", Font.BOLD, 20));
      pnlSongName.add(lblSongTitle);
      
      /* Label for artist title */
      lblArtistTitle = new JLabel("Sample Artist Name");
      lblArtistTitle.setFont(new Font("Nanum Gothic", Font.BOLD, 15));
      pnlSongName.add(lblArtistTitle);
      
      /** ====================== Body of music player =========================== */
      /* Panel for Output */
      pnlOutput = new JPanel();
      pnlOutput.setBorder(new EmptyBorder(0, 10, 10, 10));
      frame.getContentPane().add(pnlOutput, BorderLayout.CENTER);
      GridBagLayout gbl_pnlOutput = new GridBagLayout();
      gbl_pnlOutput.columnWidths = new int[]{400, 0};
      gbl_pnlOutput.rowHeights = new int[]{20, 162, 0, 0};
      gbl_pnlOutput.columnWeights = new double[]{1.0, Double.MIN_VALUE};
      gbl_pnlOutput.rowWeights = new double[]{0.0, 1.0, 1.0, Double.MIN_VALUE};
      pnlOutput.setLayout(gbl_pnlOutput);
      
      /* ======================== 1. Time output =================================== */
      pnlTimeOutput = new JPanel();
      GridBagConstraints gbc_pnlTimeOutput = new GridBagConstraints();
      gbc_pnlTimeOutput.insets = new Insets(0, 0, 5, 0);
      gbc_pnlTimeOutput.anchor = GridBagConstraints.NORTH;
      gbc_pnlTimeOutput.fill = GridBagConstraints.HORIZONTAL;
      gbc_pnlTimeOutput.gridx = 0;
      gbc_pnlTimeOutput.gridy = 0;
      pnlOutput.add(pnlTimeOutput, gbc_pnlTimeOutput);
      pnlTimeOutput.setLayout(new GridLayout(0, 1, 0, 0));
      
      /* Panel for time */
      pnlTimeOutput.setLayout(new BorderLayout(0, 0));
      pnlTime = new JPanel();
      FlowLayout flowLayout = (FlowLayout) this.pnlTime.getLayout();
      flowLayout.setHgap(1);
      pnlTimeOutput.add(pnlTime);
      
      /* Label for time */
      lblTime = new JLabel("Time");
      lblTime.setFont(new Font("Nanum Gothic", Font.BOLD, 15));
      pnlTime.add(lblTime);
      
      /* Progress bar */
      progressBar = new JProgressBar();
      this.progressBar.addMouseListener(new MouseAdapter() 
      {
      	@Override
      	public void mouseClicked(MouseEvent arg0) 
      	{
      		double curPos = arg0.getX(); // current clicked position
          	double tot = progressBar.getWidth(); // total progress bar length
          	double rate = curPos / tot; // percentage of current clicked position in the progress bar
          	
          	progressBar.setValue((int)((player.total) * rate / (player.total) * 100)); // set progress label
          	
          	player.pause(); // pause the player
          	
          	int minute = (int)(progB.totalSec * rate / 60); // calculate minute
          	int second = (int)(progB.totalSec * rate % 60); // calculate second
          	
          	lblTime.setText(((minute < 10) ? "0" + minute : minute) + ":" + ((second < 10) ? "0" : second) + " / " + progB.totalTimeString);
          	player.stopped = (int)((player.total) * rate); // set playing position
          	player.resume();
          	
            btnPause.setEnabled(true);
            btnBack.setEnabled(true);
            btnNext.setEnabled(true);
            btnStop.setEnabled(true);
            btnPlay.setEnabled(false);
      	}
      });
      pnlTime.add(progressBar);
      
      /* ======================== 2. Controller =================================== */
      pnlController = new JPanel();
      pnlTimeOutput.add(pnlTime, BorderLayout.NORTH);
      pnlTimeOutput.add(pnlController);
      this.pnlController.setLayout(new GridLayout(2, 0, 0, 0));
      
      /** ====================== a. Panel for MP3 control buttons ================ */
      this.pnlButton = new JPanel();
      this.pnlController.add(this.pnlButton);
      pnlButton.addKeyListener(this);
      
      /* Back button */
      btnBack = new JButton(new ImageIcon("src/back.png"));
      this.pnlButton.add(this.btnBack);
      btnBack.addActionListener(this);
      btnBack.addKeyListener(this);
      
      /* Play button */
      btnPlay = new JButton(new ImageIcon("src/play.png"));
      this.pnlButton.add(this.btnPlay);
      btnPlay.addActionListener(this);
      btnPlay.addKeyListener(this);
      
      /* Pause button */
      btnPause =  new JButton(new ImageIcon("src/pause.png"));
      this.pnlButton.add(this.btnPause);
      btnPause.addActionListener(this);
      btnPause.addKeyListener(this);
      
      /* Stop button */
      btnStop = new JButton(new ImageIcon("src/stop.png"));
      this.pnlButton.add(this.btnStop);
      btnStop.addActionListener(this);
      btnStop.addKeyListener(this);
      
      /* Next button */
      btnNext = new JButton(new ImageIcon("src/next.png"));
      this.pnlButton.add(this.btnNext);
      btnNext.addActionListener(this);
      btnNext.addKeyListener(this);
   
      /** ================= b. Panel for volume control ========================= */
      this.pnlVolume = new JPanel();
      this.pnlController.add(this.pnlVolume);
      this.pnlVolume.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
      
      /* Label for volume */
      lblVol = new JLabel(new ImageIcon("src/volume.png"));
      this.pnlVolume.add(this.lblVol);
      
      /* Slider for volume */
      slider = new JSlider();
      slider.addChangeListener(new ChangeListener() // if detect change on slider
      {
            @Override
            public void stateChanged(ChangeEvent e) 
            {
                JSlider source = (JSlider)e.getSource(); // get information
                 if (!source.getValueIsAdjusting())
                 {
                   System.out.println("Set volume to " + (int)source.getValue()); // print out for testing
                   volumeController.execute();
                   volumeController.volumeControl((float)(source.getValue())/100); // set volume at desired level
                   
                   lblVolSize.setText("" + (int)source.getValue()); // update volume size label
                 }
            }
        });
      this.pnlVolume.add(this.slider);
      slider.addKeyListener(this);
      
      /* Label for Volume Size */
      this.lblVolSize = new JLabel("50"); // default volume size is 50
      this.lblVolSize.setFont(new Font("Dialog", Font.BOLD, 18));
      this.pnlVolume.add(this.lblVolSize);
      
      /* ======================== 3. Music List ======================================== */
      /* Panel for List */
      pnlList = new JPanel();
      GridBagConstraints gbc_pnlList = new GridBagConstraints();
      gbc_pnlList.insets = new Insets(0, 0, 5, 0);
      gbc_pnlList.fill = GridBagConstraints.BOTH;
      gbc_pnlList.gridx = 0;
      gbc_pnlList.gridy = 1;
      pnlOutput.add(pnlList, gbc_pnlList);
      pnlList.setLayout(new BorderLayout(0, 0));
      
      /* Panel for ShowList */
      pnlShowList = new JPanel();
      pnlList.add(pnlShowList, BorderLayout.NORTH);
      pnlShowList.setLayout(new GridLayout(0, 3, 0, 0));
      
      /* Label for Song Name */
      lblSongName = new JLabel("Song name");
      lblSongName.setFont(new Font("Nanum Gothic", Font.BOLD, 15));
      pnlShowList.add(lblSongName);
      
      /* Label for Artist */
      lblArtist = new JLabel("Artist");
      lblArtist.setFont(new Font("Nanum Gothic", Font.BOLD, 15));
      pnlShowList.add(lblArtist);
      
      /* Label for Duration */
      lblDuration = new JLabel("Duration");
      lblDuration.setFont(new Font("Nanum Gothic", Font.BOLD, 15));
      scrollPane = new JScrollPane();
      pnlList.add(scrollPane, BorderLayout.CENTER);
      pnlShowList.add(lblDuration);
     
      /* JList */
      listModel = new DefaultListModel(); // instantiate DefaultListModel
      musicList = new ArrayList<String>(); // instantiate ArrayList MusicList
      music = new ArrayList<Music>(); // instantiate ArrayList for Music
      list = new JList(listModel); // instantiate JList with DefaultListModel
      list.setVisibleRowCount(1);
      list.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION); //instantiate multiple selection
      scrollPane.setViewportView(list);

      /* ====================== 4. File control buttons ============================ */
      /* Panel for Control Menu */
      pnlMenu = new JPanel();
      GridBagConstraints gbc_pnlMenu = new GridBagConstraints();
      gbc_pnlMenu.fill = GridBagConstraints.BOTH;
      gbc_pnlMenu.gridx = 0;
      gbc_pnlMenu.gridy = 2;
      pnlOutput.add(pnlMenu, gbc_pnlMenu);
      GridBagLayout gbl_pnlMenu = new GridBagLayout();
      gbl_pnlMenu.columnWidths = new int[]{90, 0, 0, 0, 200, 0};
      gbl_pnlMenu.rowHeights = new int[]{50, 50, 50, 50, 0};
      gbl_pnlMenu.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
      gbl_pnlMenu.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
      pnlMenu.setLayout(gbl_pnlMenu);

      /* Open File Button */
      btnOpenFile = new JButton(new ImageIcon("src/OpenFile.png"));
      btnOpenFile.addActionListener(this);
      // Layout for Open file
      GridBagConstraints gbc_btnOpenFile = new GridBagConstraints();
      gbc_btnOpenFile.insets = new Insets(0, 0, 5, 5);
      gbc_btnOpenFile.gridx = 1;
      gbc_btnOpenFile.gridy = 0;
      pnlMenu.add(btnOpenFile, gbc_btnOpenFile);
      // Label for Open File
      lblOpenFile = new JLabel("Open File");
      lblOpenFile.setFont(new Font("Nanum Gothic", Font.BOLD, 15));
      GridBagConstraints gbc_lblOpenFile = new GridBagConstraints();
      gbc_lblOpenFile.fill = GridBagConstraints.BOTH;
      gbc_lblOpenFile.insets = new Insets(0, 0, 5, 5);
      gbc_lblOpenFile.gridx = 2;
      gbc_lblOpenFile.gridy = 0;
      pnlMenu.add(lblOpenFile, gbc_lblOpenFile);
      
      /* Open Play List Button */
      btnOpenPlaylist = new JButton(new ImageIcon("src/OpenPlayList.png"));
      btnOpenPlaylist.addActionListener(this);
      // Layout for Open Play List
      GridBagConstraints gbc_btnOpenPlaylist = new GridBagConstraints();
      gbc_btnOpenPlaylist.insets = new Insets(0, 0, 5, 5);
      gbc_btnOpenPlaylist.gridx = 3;
      gbc_btnOpenPlaylist.gridy = 0;
      pnlMenu.add(btnOpenPlaylist, gbc_btnOpenPlaylist);
      // Label for Open Play List
      lblOpenPlaylist = new JLabel("Open Playlist");
      lblOpenPlaylist.setFont(new Font("Nanum Gothic", Font.BOLD, 15));
      GridBagConstraints gbc_lblOpenPlaylist = new GridBagConstraints();
      gbc_lblOpenPlaylist.fill = GridBagConstraints.BOTH;
      gbc_lblOpenPlaylist.insets = new Insets(0, 0, 5, 0);
      gbc_lblOpenPlaylist.gridx = 4;
      gbc_lblOpenPlaylist.gridy = 0;
      pnlMenu.add(lblOpenPlaylist, gbc_lblOpenPlaylist);
      
      /* Add Song Button */
      btnAddSong = new JButton(new ImageIcon("src/AddSong.png"));
      btnAddSong.addActionListener(this);
      btnAddSong.setEnabled(false);
      // Layout for Add Song
      GridBagConstraints gbc_btnAddSong = new GridBagConstraints();
      gbc_btnAddSong.insets = new Insets(0, 0, 5, 5);
      gbc_btnAddSong.gridx = 1;
      gbc_btnAddSong.gridy = 1;
      pnlMenu.add(btnAddSong, gbc_btnAddSong);
      // Label for Add Song
      lblAddSong = new JLabel("Add Song");
      lblAddSong.setFont(new Font("Nanum Gothic", Font.BOLD, 15));
      GridBagConstraints gbc_lblAddSong = new GridBagConstraints();
      gbc_lblAddSong.fill = GridBagConstraints.BOTH;
      gbc_lblAddSong.insets = new Insets(0, 0, 5, 5);
      gbc_lblAddSong.gridx = 2;
      gbc_lblAddSong.gridy = 1;
      pnlMenu.add(lblAddSong, gbc_lblAddSong);
      
      /* New Play List Button */
      btnNewPlaylist = new JButton(new ImageIcon("src/NewPlayList.png"));
      btnNewPlaylist.addActionListener(this);
      btnNewPlaylist.setEnabled(false);
      // Layout for New Play List
      GridBagConstraints gbc_btnNewPlaylist = new GridBagConstraints();
      gbc_btnNewPlaylist.insets = new Insets(0, 0, 5, 5);
      gbc_btnNewPlaylist.gridx = 3;
      gbc_btnNewPlaylist.gridy = 1;
      pnlMenu.add(btnNewPlaylist, gbc_btnNewPlaylist);
      // Label for New Play List
      lblNewPlaylist = new JLabel("New Playlist");
      lblNewPlaylist.setFont(new Font("Nanum Gothic", Font.BOLD, 15));
      GridBagConstraints gbc_lblNewPlaylist = new GridBagConstraints();
      gbc_lblNewPlaylist.fill = GridBagConstraints.BOTH;
      gbc_lblNewPlaylist.insets = new Insets(0, 0, 5, 0);
      gbc_lblNewPlaylist.gridx = 4;
      gbc_lblNewPlaylist.gridy = 1;
      pnlMenu.add(lblNewPlaylist, gbc_lblNewPlaylist);
      
      /* Remove Song Button */
      btnRemoveSong = new JButton(new ImageIcon("src/RemoveSong.png"));
      btnRemoveSong.addActionListener(this);
      btnRemoveSong.setEnabled(false);
      // Layout for Remove Song
      GridBagConstraints gbc_btnRemoveSong = new GridBagConstraints();
      gbc_btnRemoveSong.insets = new Insets(0, 0, 5, 5);
      gbc_btnRemoveSong.gridx = 1;
      gbc_btnRemoveSong.gridy = 2;
      pnlMenu.add(btnRemoveSong, gbc_btnRemoveSong);
      // Label for Remove Song
      lblRemoveSong = new JLabel("Remove Song");
      lblRemoveSong.setFont(new Font("Nanum Gothic", Font.BOLD, 15));
      GridBagConstraints gbc_lblRemoveSong = new GridBagConstraints();
      gbc_lblRemoveSong.fill = GridBagConstraints.BOTH;
      gbc_lblRemoveSong.insets = new Insets(0, 0, 5, 5);
      gbc_lblRemoveSong.gridx = 2;
      gbc_lblRemoveSong.gridy = 2;
      pnlMenu.add(lblRemoveSong, gbc_lblRemoveSong);
      
      /* Save Play List Button */
      btnSavePlaylist = new JButton(new ImageIcon("src/SavePlayList.png"));
      btnSavePlaylist.addActionListener(this);
      btnSavePlaylist.setEnabled(false);
      // Layout for Save Play List
      GridBagConstraints gbc_btnSavePlaylist = new GridBagConstraints();
      gbc_btnSavePlaylist.insets = new Insets(0, 0, 5, 5);
      gbc_btnSavePlaylist.gridx = 3;
      gbc_btnSavePlaylist.gridy = 2;
      pnlMenu.add(btnSavePlaylist, gbc_btnSavePlaylist);
      // Label for Save Play List
      lblSavePlaylist = new JLabel("Save Playlist");
      lblSavePlaylist.setFont(new Font("Nanum Gothic", Font.BOLD, 15));
      GridBagConstraints gbc_lblSavePlaylist = new GridBagConstraints();
      gbc_lblSavePlaylist.fill = GridBagConstraints.BOTH;
      gbc_lblSavePlaylist.insets = new Insets(0, 0, 5, 0);
      gbc_lblSavePlaylist.gridx = 4;
      gbc_lblSavePlaylist.gridy = 2;
      pnlMenu.add(lblSavePlaylist, gbc_lblSavePlaylist);
      
      /* Remove Play List Button */
      btnRemovePlaylist = new JButton(new ImageIcon("src/RemovePlayList.png"));
      btnRemovePlaylist.addActionListener(this);
      btnRemovePlaylist.setEnabled(false);
      // Layout for Remove Play List
      GridBagConstraints gbc_btnRemovePlaylist = new GridBagConstraints();
      gbc_btnRemovePlaylist.insets = new Insets(0, 0, 0, 5);
      gbc_btnRemovePlaylist.gridx = 3;
      gbc_btnRemovePlaylist.gridy = 3;
      pnlMenu.add(btnRemovePlaylist, gbc_btnRemovePlaylist);
      // Label for Remove Play List
      lblRemovePlaylist = new JLabel("Remove Playlist");
      lblRemovePlaylist.setFont(new Font("Nanum Gothic", Font.BOLD, 15));
      GridBagConstraints gbc_lblRemovePlaylist = new GridBagConstraints();
      gbc_lblRemovePlaylist.fill = GridBagConstraints.BOTH;
      gbc_lblRemovePlaylist.gridx = 4;
      gbc_lblRemovePlaylist.gridy = 3;
      pnlMenu.add(lblRemovePlaylist, gbc_lblRemovePlaylist);   
      
      //<---------set disable all button--------------->      
      btnPause.setEnabled(false);      
      btnBack.setEnabled(false);      
      btnNext.setEnabled(false);      
      btnStop.setEnabled(false);      
      btnPlay.setEnabled(false);
   }
   
   public void updateTitleLabel() // update title label according to which music is on play
   {
      lblSongTitle.setText(music.get(list.getSelectedIndex()).getMusicName());
      lblArtistTitle.setText(music.get(list.getSelectedIndex()).getMusicArtist());
   }
   
   @Override
   public void actionPerformed(ActionEvent e) 
   {
      /** ================================ 1. MP3 playing manipulation ============================== */
      /* Back Button */
      if(e.getSource() == btnBack) 
      {
         try
         {
            try
            {
               System.out.println("Back"); // for test only
               player.player.close(); // close Player object (terminate MP3 playing)
               progB.cancel(true); //cancel progress implement
            }
            catch(Exception ex) { System.err.println("There is no MP3 playing thread"); }
            finally
            {
               if(list.getSelectedIndex() > 0) // if it is not the first song
               {
                  list.setSelectedIndex(list.getSelectedIndex() - 1); // go previous
                  updateTitleLabel(); // and update label
               }
               else // print error message on console
                  throw new Exception("There is no previous song");
            }
         }
         catch (Exception e1) 
         { 
        	 JOptionPane.showMessageDialog(null, e1.getMessage(), "Notice", JOptionPane.ERROR_MESSAGE);
         }
         finally
         {
            String path = music.get(list.getSelectedIndex()).getMusicPath(); // get path from selected list item
            player.setPath(path); // set path
            player.play(-1); // play the song
            
            //get progressBar info      
            progB = new ProgressBar(progressBar,lblTime,music.get(list.getSelectedIndex()));      
            //excute progressBar      
            progB.execute();      
            //<---------set enable Button except plaButton --------------->      
            btnPause.setEnabled(true);      
            btnBack.setEnabled(true);      
            btnNext.setEnabled(true);      
            btnStop.setEnabled(true);      
            btnPlay.setEnabled(false);
         }
      }
      
      /* Play Button */
      if(e.getSource() == btnPlay)
      {
         if(pause_flag == false) // never paused before
         {
            System.out.println("Play"); // for test only
            String path = music.get(list.getSelectedIndex()).getMusicPath(); // get path from selected list item
            updateTitleLabel(); // update song title label
            player.setPath(path); // set path
            player.play(-1); // play the song
            
            //get progressBar info      
            progB = new ProgressBar(progressBar,lblTime,music.get(list.getSelectedIndex()));      
            //excute progressBar      
            progB.execute();      
            //<---------set enable Button except playButton--------------->      
            btnPause.setEnabled(true);      
            btnBack.setEnabled(true);      
            btnNext.setEnabled(true);      
            btnStop.setEnabled(true);      
            btnPlay.setEnabled(false);
         }
         else // paused at least once
         {
            System.out.println("Resume"); // for test only
            player.resume(); // resume MP3 playing
            
            //resume progress    
            try
            {
            	synchronized (progB) 
            	{
            		pause_flag = false;
            		progB.notifyAll();
            		System.out.println("notify");
				}
            }
            catch(Exception ex)
            {
            	ex.getMessage();
            }
            
            //<---------set enable Button except pauseButton--------------->      
            btnPause.setEnabled(true);      
            btnBack.setEnabled(true);      
            btnNext.setEnabled(true);      
            btnStop.setEnabled(true);      
            btnPlay.setEnabled(false);
         }
         play_flag = true;
      }
      
      /* Pause Button */
      if(e.getSource() == btnPause)
      {
         System.out.println("Pause"); // for test only
         pause_flag = true; // set flag that it is paused at least once
         
         play_flag = false;
         player.pause(); // pause MP3 playing

         double tot = player.total;
         double progressed = player.total - player.stopped;
         System.out.println(progressed);
         System.out.println(tot);
         System.out.println(progressed / tot * 100);
         progressBar.setValue((int)(progressed / tot * 100));
         double total = progB.totalSec * (progressed / tot);
         int min = (int) (total / 60);
         int sec = (int) (total % 60);
         String result = "" + ((min < 10) ? "0" + min : min) + ":" + ((sec < 10) ? "0" + sec : sec);
         
         progB.cancel(true); //stop progress bar implement      
         lblTime.setText(result + " / " + progB.totalTimeString); // Reset progress
         progB.pause_set = true;
         
         progB = new ProgressBar(progressBar,lblTime,music.get(list.getSelectedIndex()));      
         System.out.println(music.get(list.getSelectedIndex()));
         
         //<---------set enable Button except PauseButton--------------->      
         btnPause.setEnabled(false);      
         btnBack.setEnabled(true);      
         btnNext.setEnabled(true);      
         btnStop.setEnabled(false);      
         btnPlay.setEnabled(true);      
      }
      
      /* Stop Button */
      if(e.getSource() == btnStop)
      {
         try 
         {
            System.out.println("Stop"); // for test only
            player.player.close(); // close Player object (terminate MP3 playing)
            pause_flag = false; // stop means it set playing situation as default
            
            progB.cancel(true); //stop progress bar implement      
            lblTime.setText("00:00 / 00:00"); // Reset progress;      
                  
            //<---------set enable Button except pause, stop --------------->      
            btnPause.setEnabled(false);      
            btnBack.setEnabled(true);      
            btnNext.setEnabled(true);      
            btnStop.setEnabled(false);      
            btnPlay.setEnabled(true);
         }
         catch(Exception ex) { System.err.println("MP3 Playing thread is terminated"); }
      }
      
      /* Next Button */
      if(e.getSource() == btnNext)
      {
         try
         {
            try 
            {
               System.out.println("Next"); // for test only
               player.player.close(); // close Player object (terminate MP3 playing)
               progB.cancel(true); //cancel progress implement
            }
            catch(Exception ex1) 
            { 
            	JOptionPane.showMessageDialog(null, "There is no MP3 playing thread", "Notice", JOptionPane.ERROR_MESSAGE);
            }
            finally
            {
               if(list.getSelectedIndex() < listModel.getSize() - 1) // if it reaches the end of the list
               {
                  list.setSelectedIndex(list.getSelectedIndex() + 1);
                  updateTitleLabel();  // update song title label
               }
               else
                  throw new Exception("There is no next song!");
            }
         }
         catch(Exception ex2) 
         { 
        	 JOptionPane.showMessageDialog(null, ex2.getMessage(), "Notice", JOptionPane.ERROR_MESSAGE);
         }
         finally
         {
            String path = music.get(list.getSelectedIndex()).getMusicPath(); // get path from selected list item
            player.setPath(path); // set path
            player.play(-1); // play the song
            
            //get progressBar info      
            progB = new ProgressBar(progressBar,lblTime,music.get(list.getSelectedIndex()));      
            //excute progressBar      
            progB.execute();      
            //<---------set enable Button except plaButton --------------->      
            btnPause.setEnabled(true);      
            btnBack.setEnabled(true);      
            btnNext.setEnabled(true);      
            btnStop.setEnabled(true);      
            btnPlay.setEnabled(false);
         }
      }
      
      /** ================================ 2. File manipulation =========================================== */
      /* Open File Button */
      if(e.getSource() == btnOpenFile) 
      {
         JFileChooser fc = new JFileChooser();
         FileNameExtensionFilter filter = new FileNameExtensionFilter("mp3","mp3");
         fc.setFileFilter(filter);
         int returnVal = fc.showOpenDialog(MainGUI.this);
         
         //first file open      
         //<---------set just push play button--------------->      
         btnPause.setEnabled(false);      
         btnBack.setEnabled(false);      
         btnNext.setEnabled(false);      
         btnStop.setEnabled(false);      
         btnPlay.setEnabled(true);
         
         if(returnVal==JFileChooser.APPROVE_OPTION) 
         {
            File file = fc.getSelectedFile();
            fileName=null;
            filePath=null;
            
            try 
            {
               FileReader fis = new FileReader(file);
               BufferedReader reader = new BufferedReader(fis);
               
               MusicTimer t = new MusicTimer(file); //add music timer                     
               t.calTime(); //calculate time
               
               String fileName = file.getName(); // get file name
               String[] split = fileName.split(";"); // use semicolon as denominator
               
               musicName = split[0]; // set name
               String temp = split[1]; 
               String[] tempArr = temp.split(".mp3");
               musicArtist = tempArr[0]; // set artist
               
               musicTime = t.getTime(); // set playing time
               musicPath = file.getPath(); // set path
               
               lblSongTitle.setText(musicName); // set song title label
               lblArtistTitle.setText(musicArtist); // set 
               
               musicNum = 0;
               
               listModel.clear();
               musicList.clear();
               music.clear();
               
               music.add(new Music(musicNum+1,musicName,musicArtist,musicTime,musicPath)); // add to music

               String list = String.format("%3d\t%-34s\t%-41s\t%s ",music.get(musicNum).getMusicNum(),      
                       music.get(musicNum).getMusicName(),music.get(musicNum).getMusicArtist(),      
                       music.get(musicNum).getMusicTime());   //set format      
                 musicList.add(list); // add to music list
               
               for(String song : musicList) 
                  listModel.addElement(song);
            } 
            catch (FileNotFoundException e1) { e1.printStackTrace(); }
         }
         list.setSelectedIndex(0); // put focus on first element of list

         if(musicList.size() > 0)
         {
        	 btnAddSong.setEnabled(true);
        	 btnRemoveSong.setEnabled(true);
        	 btnNewPlaylist.setEnabled(true);
        	 btnSavePlaylist.setEnabled(true);
        	 btnRemovePlaylist.setEnabled(true);
         }
      }
      
      /* Add Song Button */
      if(e.getSource() == btnAddSong) 
      {
         JFileChooser fc = new JFileChooser();
         FileNameExtensionFilter filter = new FileNameExtensionFilter("mp3","mp3");
         fc.setFileFilter(filter);
         int returnVal = fc.showOpenDialog(MainGUI.this);
         
         if(returnVal==JFileChooser.APPROVE_OPTION) 
         {
            File file = fc.getSelectedFile();
            
            try 
            {
               FileReader fis = new FileReader(file);
               String fileName = file.getName();
               String[] split = fileName.split("; ");
               
               MusicTimer t = new MusicTimer(file); //add music timer      
                  t.calTime(); //calculate time
               
               musicName = split[0]; // set name
               String temp = split[1]; 
               String[] tempArr = temp.split(".mp3");
               musicArtist = tempArr[0]; // set artist
               
               musicTime = t.getTime();
               musicPath = file.getPath();
               listModel.clear();
               
               musicNum +=1; // increase number
               music.add(new Music(musicNum+1,musicName,musicArtist,musicTime,musicPath)); // add to music
               
               String list = String.format("%2d %-34s %-41s %s ",music.get(musicNum).getMusicNum(),
                     music.get(musicNum).getMusicName(),music.get(musicNum).getMusicArtist(),
                     music.get(musicNum).getMusicTime());   //set format
               musicList.add(list); // add to music list
               
               for(String song : musicList) // add to DefaultListModel to show on GUI
                  listModel.addElement(song);
            } 
            catch (FileNotFoundException e1) { e1.printStackTrace(); }
         }
         list.setSelectedIndex(0); // put focus on first element of list
      }
      
      /* Remove Song Button */
      if(e.getSource() == btnRemoveSong) 
      {
    	 int result = JOptionPane.showConfirmDialog(null, "Are you sure delete music?", "Confirm",JOptionPane.YES_NO_OPTION);
       	 
       	 if (result == JOptionPane.OK_OPTION && musicList.size() > 0)
       	 {
       		 int delCount = 0;
                
             //delete selected music
             for (int pos : list.getSelectedIndices()) 
             {
            	 music.remove(pos - delCount);
                 delCount++;
             }
            
             musicList.clear(); // clear musicList
             listModel.clear(); // clear listModel
                 
             //update musicList
             for(int i=0;i<music.size();i++) 
             {
            	 music.get(i).setMusicNum(i+1); //update Number
              	 String list = String.format("%2d %-34s %-41s %s ",music.get(i).getMusicNum(),
                             music.get(i).getMusicName(),music.get(i).getMusicArtist(),
                             music.get(i).getMusicTime());   //set format
                 musicList.add(list); // add to music list
             }
             //set music number
             musicNum = music.size()-1;
                 
             for(String song : musicList) // add to DefaultListModel to show on GUI
            	 listModel.addElement(song);
             
             if(musicList.size() == 0)
            	 btnRemoveSong.setEnabled(false);
       	 }
      }
      
      /* Open Play List Button */
      if(e.getSource() == btnOpenPlaylist) 
      {
         //first file open
         //<---------set just push play button--------------->
         btnPause.setEnabled(false);
         btnBack.setEnabled(false);
         btnNext.setEnabled(false);
         btnStop.setEnabled(false);
         btnPlay.setEnabled(true);
         
         JFileChooser fc = new JFileChooser();
         FileNameExtensionFilter fnef1 = new FileNameExtensionFilter("txt","txt");
         fc.setFileFilter(fnef1);
         int returnVal = fc.showOpenDialog(MainGUI.this);
         
         if(returnVal==JFileChooser.APPROVE_OPTION) 
         {
            File file = fc.getSelectedFile();
            
            try 
            {
               // initialize 
               music.clear();
               musicList.clear();
               listModel.clear();
               
               fileName = file.getName(); // get file name 
               filePath = file.getPath(); // get file path
               
               FileReader fr = new FileReader(file);
               BufferedReader br = new BufferedReader(fr);
            
               String sCurrentLine;
               while((sCurrentLine = br.readLine()) != null) 
               {
                  String[] split = sCurrentLine.split(";;"); // use tab as denominator
                  
                  musicNum = Integer.parseInt(split[0]) - 1; // set number
                  musicName = split[1]; // set name
                  musicArtist = split[2]; // set artist
                  musicTime = split[3]; // set playing time
                  musicPath = split[4]; // set path
                  
                  music.add(new Music(musicNum+1,musicName,musicArtist,musicTime,musicPath)); // add to music
                  String list = String.format("%2d %-34s %-41s %s ",music.get(musicNum).getMusicNum(),
                          music.get(musicNum).getMusicName(),music.get(musicNum).getMusicArtist(),
                          music.get(musicNum).getMusicTime());   //set format
                    musicList.add(list); // add to music list
               }
               br.close();
               
                System.out.println(music.get(0).getMusicName()+" "+music.get(0).getMusicPath());
               
               for(String song : musicList) // add to DefaultListModel to show on GUI
                  listModel.addElement(song);
            } 
            catch (IOException e1) { e1.printStackTrace(); } 
         }
         list.setSelectedIndex(0); // focus on first element of list
         
         btnOpenFile.setEnabled(true);
         btnOpenPlaylist.setEnabled(true);
         btnAddSong.setEnabled(true);
         if(musicList.size() > 0)
        	 btnRemoveSong.setEnabled(true);
    	 btnNewPlaylist.setEnabled(true);
    	 btnSavePlaylist.setEnabled(true);
    	 btnRemovePlaylist.setEnabled(true);
      }
      
      /* New Play List Button */
      if(e.getSource() == btnNewPlaylist) 
      {
    	  int result = JOptionPane.showConfirmDialog(null, "Are you sure making newPlayList?", "Confirm",JOptionPane.YES_NO_OPTION);
      	 
      	  if (result == JOptionPane.OK_OPTION)
      	  {
      		//<————set disable all button———————>
             btnPause.setEnabled(false);
             btnBack.setEnabled(false);
             btnNext.setEnabled(false);
             btnStop.setEnabled(false);
             btnPlay.setEnabled(false);
             
             music.clear();
             musicList.clear();
             listModel.clear();
      	 }
      }

      /* Remove Play List Button */
      if(e.getSource() == btnRemovePlaylist) 
      {
    	 int result = JOptionPane.showConfirmDialog(null, "Are you sure RemovePlayList?", "Confirm",JOptionPane.YES_NO_OPTION);
    	 
    	 if(result == JOptionPane.OK_OPTION) 
    	 {
    		 try
             {
                File file = new File(filePath);
                 if(fileName != null) // In case, play list exists
                 {
                    file.delete();
                    System.out.println(fileName + " is deleted!");
                    fileName = null;
                    filePath = null;
                 }
                 else // In case, play list does not exist
                    throw new Exception("Delete operation is failed!");
             }
             catch(Exception e1) 
    		 { 
            	 JOptionPane.showMessageDialog(null, e1.getMessage(), "Notice", JOptionPane.ERROR_MESSAGE);
    		 }
             
             //<————set disable all button———————>
             btnPause.setEnabled(false);
             btnBack.setEnabled(false);
             btnNext.setEnabled(false);
             btnStop.setEnabled(false);
             btnPlay.setEnabled(false);
             music.clear();
             musicList.clear();
             listModel.clear();
             
             btnOpenFile.setEnabled(true);
             btnOpenPlaylist.setEnabled(true);
             btnAddSong.setEnabled(false);
        	 btnRemoveSong.setEnabled(false);
        	 btnNewPlaylist.setEnabled(false);
        	 btnSavePlaylist.setEnabled(false);
        	 btnRemovePlaylist.setEnabled(false);
    	 }
      }
      
      /* Save Play List Button */
      if(e.getSource() == btnSavePlaylist) 
      {
    	  int result = JOptionPane.showConfirmDialog(null, "Are you sure SavePlayList?", "Confirm", JOptionPane.YES_NO_OPTION);
     	 
    	  if (result == JOptionPane.OK_OPTION)
    	  {
     		if(fileName == null) // if play list does not exist, create new one 
            {
               JFileChooser fc = new JFileChooser();
               FileNameExtensionFilter fnef1 = new FileNameExtensionFilter("txt","txt");
               fc.setFileFilter(fnef1);
               int returnVal = fc.showSaveDialog(MainGUI.this);
               
               if(returnVal == JFileChooser.APPROVE_OPTION) 
               {
                  File file = new File(fc.getSelectedFile()+".txt"); // save file in text format
                  
                  try 
                  {
                     fileName = file.getName(); // set file name
                     filePath = file.getPath(); // set file path
                     
                     
                     FileWriter fw = new FileWriter(file);
                     BufferedWriter bw = new BufferedWriter(fw);
                     
                     for(int i = 0; i <= musicNum; i++) // update music list 
                     {
                        bw.write(music.get(i).getMusicNum()+";;"+music.get(i).getMusicName()+";;"+
                     music.get(i).getMusicArtist()+";;"+music.get(i).getMusicTime()+";;"+music.get(i).getMusicPath());
                        bw.newLine();
                     }
                     
                     bw.flush();
                     bw.close();
                     System.out.println("Save success");
                  } 
                  catch (IOException e1) { e1.printStackTrace(); }
               }
            }
            else // if play list already exists, just update it
            {
               try 
               {
                  File file = new File(filePath);
                  BufferedWriter bw = new BufferedWriter(new FileWriter(file));
               
                  for(int i=0; i <= musicNum; i++) 
                  {
                     bw.write(music.get(i).getMusicNum()+";;"+music.get(i).getMusicName()+";;"+
                           music.get(i).getMusicArtist()+";;"+music.get(i).getMusicTime()+";;"+music.get(i).getMusicPath());
                     bw.newLine();
                  }
                  bw.flush();
                  bw.close();
               } 
               catch (IOException e1) { e1.printStackTrace(); }
            }
     	 }
      }
   }
   
   @Override
   public void keyPressed(KeyEvent e)
   {
      if ((e.getKeyCode() == KeyEvent.VK_B) && ((e.getModifiers() & KeyEvent.CTRL_MASK) != 0)) // back
      {
         try
         {
            try
            {
               System.out.println("Back"); // for test only
               player.player.close(); // close Player object (terminate MP3 playing)
               
               progB.cancel(true); //stop progress bar implement      
               lblTime.setText("00:00 / 00:00"); // Reset progress;    
            }
            catch(Exception ex) { System.err.println("There is no MP3 playing thread"); }
            finally
            {
               if(list.getSelectedIndex() > 0) // if it is not the first song
               {
                  list.setSelectedIndex(list.getSelectedIndex() - 1); // go previous
                  updateTitleLabel(); // and update label
               }
               else // print error message on console
            	   throw new Exception("There is no previous song");
            }
         }
         catch (Exception e1) 
         { 
        	 JOptionPane.showMessageDialog(null, e1.getMessage(), "Notice", JOptionPane.ERROR_MESSAGE);
         }
         finally
         {
            String path = music.get(list.getSelectedIndex()).getMusicPath(); // get path from selected list item
            player.setPath(path); // set path
            player.play(-1); // play the song
               
            progB = new ProgressBar(progressBar,lblTime,music.get(list.getSelectedIndex())); // get progressBar info   
            progB.execute(); // execute progressBar   
         }
      }
      else if ((e.getKeyCode() == KeyEvent.VK_P) && ((e.getModifiers() & KeyEvent.CTRL_MASK) != 0)) // play or pause
      {
         if(play_flag == false)
         {
            if(pause_flag == false) // never paused before
            {
               System.out.println("Play"); // for test only
               String path = music.get(list.getSelectedIndex()).getMusicPath(); // get path from selected list item
               updateTitleLabel(); // update song title label
               player.setPath(path); // set path
               player.play(-1); // play the song
                
               progB = new ProgressBar(progressBar,lblTime,music.get(list.getSelectedIndex())); // get progressBar info    
               progB.execute(); // execute progressBar  
            }
            else // paused at least once
            {
               System.out.println("Resume"); // for test only
               player.resume(); // resume MP3 playing
            }
            play_flag = true;
         }
         else if(play_flag == true)
         {
            System.out.println("Pause"); // for test only
            pause_flag = true; // set flag that it is paused at least once
            player.pause(); // pause MP3 playing
            play_flag = false;
         }
      }
      else if ((e.getKeyCode() == KeyEvent.VK_S) && ((e.getModifiers() & KeyEvent.CTRL_MASK) != 0)) // stop
      {
         try 
         {
            System.out.println("Stop"); // for test only
            player.player.close(); // close Player object (terminate MP3 playing)
            pause_flag = false; // stop means it set playing situation as default
            
            progB.cancel(true); //stop progress bar implement      
            lblTime.setText("00:00 / 00:00"); // Reset progress;    
         }
         catch(Exception ex) { System.err.println("MP3 Playing thread is terminated"); }
      }
      else if ((e.getKeyCode() == KeyEvent.VK_F) && ((e.getModifiers() & KeyEvent.CTRL_MASK) != 0)) // next
      {
         try
         {
            try 
            {
               System.out.println("Next"); // for test only
               player.player.close(); // close Player object (terminate MP3 playing)
               
               progB.cancel(true); //stop progress bar implement      
               lblTime.setText("00:00 / 00:00"); // Reset progress;    
            }
            catch(Exception ex1) { System.err.println("There is no MP3 playing thread"); }
            finally
            {
               if(list.getSelectedIndex() < listModel.getSize() - 1) // if it reaches the end of the list
               {
                  list.setSelectedIndex(list.getSelectedIndex() + 1);
                  updateTitleLabel();  // update song title label
               }
               else
                  throw new Exception("There is no next song!");
            }
         }
         catch(Exception ex2) 
         { 
        	 JOptionPane.showMessageDialog(null, ex2.getMessage(), "Notice", JOptionPane.ERROR_MESSAGE);
         }
         finally
         {
            String path = music.get(list.getSelectedIndex()).getMusicPath(); // get path from selected list item
            player.setPath(path); // set path
            player.play(-1); // play the song
            
            progB = new ProgressBar(progressBar,lblTime,music.get(list.getSelectedIndex())); // get progressBar info    
            progB.execute(); // execute progressBar  
         }
      }
   }

   @Override
   public void keyReleased(KeyEvent e) { }

   @Override
   public void keyTyped(KeyEvent e) { }
}